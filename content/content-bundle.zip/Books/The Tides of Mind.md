Full Title: The Tides of Mind
Author: [[David Gelernter]]
Category: books
Document Tags: [[Psychology MOC]]

## Highlights & Notes
> [!quote] Highlight
>  The brain doesn't believe things, or get excited or grow wistful or daydream about a farm by the ocean in Maine, with a studio overlooking the sea. The mind does those things. John Milton wrote, "The mind is its own place." The mind is the landscape we invent, the landscape of us.  ^448145161
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  A father teaches his children "not just to speak properly but to think logically, to classify, to analyze, to describe, to enumerate" (Philip Roth, The Human Stain)  ^449571134
> > [!note] Note
> > 
> > 

