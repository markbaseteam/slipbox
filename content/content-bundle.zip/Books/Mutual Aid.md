Full Title: Mutual Aid
Author: [[Dean Spade]]
Category: books
Document Tags: [[Health MOC]] [[Sociology MOC]]

## Highlights & Notes
> [!quote] Highlight
>  Mutual aid is collective coordination to meet each other’s needs, usually from an awareness that the systems we have in place are not going to meet them.  ^392911959
> > [!note] Note
> > 
> > 

