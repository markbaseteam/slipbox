Full Title: Enlightenment Now
Author: [[Steven Pinker]]
Category: books
Document Tags: [[Life Design MOC]] [[Philosophy MOC]] [[Sociology MOC]] [[Writing MOC]]

## Highlights & Notes
> [!quote] Highlight
>  Optimism (in the sense that I have advocated) is the theory that all failures—all evils—are due to insufficient knowledge. . . . Problems are inevitable, because our knowledge will always be infinitely far from complete. Some problems are hard, but it is a mistake to confuse hard problems with problems unlikely to be solved. Problems are soluble, and each particular evil is a problem that can be solved.  ^392911973
> > [!note] Note
> > Optimism is possibly only through a "giving up" of absolute truth. We will never be able to retain the actual truth, thus there is beauty in the pursuit of truth.
> > 

> [!quote] Highlight
>  Information about human progress, though absent from major news outlets and intellectual forums, is easy enough to find. The data are not entombed in dry reports but are displayed in gorgeous Web sites, particularly [[Max Roser]]'s Our World in Data, [[Marian Tupy]]’s HumanProgress, and [[Hans Rosling]]’s Gapminder.  ^392911974
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  The economist [[Steven Radelet]] has pointed out that “the improvements in health among the global poor in the last few decades are so large and widespread that they rank among the greatest achievements in human history. Rarely has the basic well-being of so many people around the world improved so substantially, so quickly. Yet few people are even aware that it is happening.”  ^392911975
> > [!note] Note
> > Knowledge (or Awareness) has improved alongside well-being. We were in the dark when things were worse, and as our health increased, so did our awareness of the myriad problems that exist.
> > 

