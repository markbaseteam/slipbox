Full Title: Chokehold
Author: [[Paul Butler]]
Category: books
Document Tags: [[Health MOC]] [[Sociology MOC]]

## Highlights & Notes
> [!quote] Highlight
>  The main problem has never been bad apple cops. The main problem is that the system is working the way it is supposed to, and that does not change regardless of who is the president.  ^392911971
> > [!note] Note
> > 
> > 

> [!quote] Highlight
>  A vote for a conservative is an investment in the property value of one’s whiteness.  ^392911972
> > [!note] Note
> > 
> > 

