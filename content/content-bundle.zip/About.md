---
home: true
---

Welcome to the Slipbox. This is a space-within-a-space of my note folder – a home for ruminating out loud. 

[Email me](turney.spencer@gmail.com) if you have questions.

Test
