URL: https://aaronzlewis.com/blog/2014/06/01/solved-conversations/
Author: [[Aaron Z. Lewis]]
Date: [[06-01-2014]]
Tags: [[Communication MOC]] [[Life Design MOC]] [[Psychology MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>Solved conversations take the creativity out of interaction.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Conversation about the weather or a crazy weekend party may be boring, but they don’t seem to do any real harm. What’s dangerous are solved conversations about things that really matter.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Imagine what would happen if the conversations between panelists on Fox/CNN/MSNBC were not solved.<br>
>>[!note]
>>What does “solved” mean here? You could argue the reverse - that groupthink is myopically focused on the purported “solve”, even if independent thinkers see it as a false truth. In reality, independent thinkers open to new facts and data are less likely to obsess over a solve in any finality
</p>