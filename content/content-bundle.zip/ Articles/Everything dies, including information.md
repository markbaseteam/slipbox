URL: https://www.technologyreview.com/2022/10/26/1061308/death-of-information-digitization/
Author: [[Erik Sherman]]
Date: [[10-26-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Everything dies: people, machines, civilizations.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Perhaps we can find some solace in knowing that all the meaningful things we’ve learned along the way will survive. But even knowledge has a life span. Documents fade. Art goes missing. Entire libraries and collections can face quick and unexpected destruction.<br>
>>[!note]
>>
</p><br>

>[!quote]
>what we think is permanent isn’t. Digital storage systems can become unreadable in as little as three to five years. Librarians and archivists race to copy things over to newer formats.<br>
>>[!note]
>>
</p>