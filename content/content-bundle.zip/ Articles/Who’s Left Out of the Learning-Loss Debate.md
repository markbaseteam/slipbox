URL: https://www.newyorker.com/news/essay/whos-left-out-of-the-learning-loss-debate
Author: [[Keeanga-Yamahtta Taylor]]
Date: [[10-12-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>According to the Pew Research Center, Black parents tended to worry about the health and safety of their children and teachers. White parents also worried about the safety of teachers, but they tended to worry more about the impact of school closures on their children’s academic achievements than their children contracting COVID.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Today’s recollections regarding remote learning and school closures make sense only by minimizing the threat posed by the virus then and by all but completely ignoring the concerns of Black and brown parents.<br>
>>[!note]
>>
</p><br>

>[!quote]
>There is little effort to understand the deep mistrust Black parents have for school administrators and local officials who have lied to them before about the safety of their children’s schools and the potential threats to their children’s health.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Those who have tried to wield learning loss as a cudgel to bash teachers’ unions or to score other political points haven’t been nearly as creative in offering solutions.<br>
>>[!note]
>>
</p><br>

>[!quote]
>A real plan for recovery from the devastation of the pandemic in public education can be found in the strikes initiated by teachers and their unions.<br>
>>[!note]
>>
</p>