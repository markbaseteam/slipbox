URL: https://milan.cvitkovic.net/writing/things_youre_allowed_to_do/
Author: [[Milan Cvitkovic]]
Date: [[12-21-2020]]
Tags: [[Aesthetics MOC]] [[Learning MOC]] [[Life Design MOC]] 

>[!tip]
>Slightly obnoxious but good reminder of the excited about life strategies that enable success and that more people should have access to


## Highlights
<br>

>[!quote]
>Then start conversations with strangers by saying "Hi, I'm a writer doing a piece about <location/circumstance you're in>.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Start a blog or substack so you can say "I'm a writer" without lying. Then start conversations with strangers by saying "Hi, I'm a writer doing a piece about <location/circumstance you're in>. Can I ask you a few questions?" * This is especially handy when traveling or at a restaurant.<br>
>>[!note]
>>
</p>