URL: https://getmatter.com/email/29011192/?token=29011192%3AJ9JblxoV_MxGve8ODYTR5cHnPDU
Author: [[Zach Seward]]
Date: [[08-08-2023]]
Tags: [[Communication MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>advertised value is what gets, well, advertised—by the lotteries themselves and in frenzied media coverage whenever the number grows large enough.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Huge jackpots are the lifeblood of any lottery, dangling unimaginably large sums in the face of vanishingly small odds. They keep regular players chasing an impossible dream and the broader public interested in lotteries, too. This is a pretty grumpy take on my part, I know. But lotteries prey on the poor, and the hoopla around billion-dollar jackpots abets these state-sponsored scams.<br>
>>[!note]
>>
</p>