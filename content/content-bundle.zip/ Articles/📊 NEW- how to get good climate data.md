URL: https://getmatter.com/email/29193049/?token=29193049%3AZ3dn1nA7e2jRKu70-83BcTb6UYQ
Author: [[]]
Date: [[08-11-2023]]
Tags: [[Health MOC]] [[Journalism MOC]] [[Science MOC]] 


## Highlights
<br>

>[!quote]
>he number of people saying that public service media is important for society is significantly higher than the number who say it's important for them personally in almost every market. We posed these questions in a subset of countries home to public service media that are generally seen as being relatively independent of government. This suggests some people see public service media as something that is good even if they don't rely on them. |<br>
>>[!note]
>>Interesting note re: media for thee but not for me. Implications for [[misinformation]]?
</p><br>

>[!quote]
>he number of people saying that public service media is important for society is significantly higher than the number who say it's important for them personally in almost every market. We posed these questions in a subset of countries home to public service media that are generally seen as being relatively independent of government. This suggests some people see public service media as something that is good even if they don't rely on the<br>
>>[!note]
>>
</p>