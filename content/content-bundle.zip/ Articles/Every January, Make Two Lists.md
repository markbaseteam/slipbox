URL: https://getmatter.com/email/17294164/?token=17294164%3Ak_BjPIeCNEixF7YcoJRCsFnA_OQ
Author: [[David Cain]]
Date: [[01-05-2023]]
Tags: 


## Highlights
<br>

>[!quote]
>List A consists of a few things you want to spend more of your life on, this year, than you have been recently. (ex. having friends over for coffee; tracking expenses in a spreadsheet) List B consists of a few things you want to spend less of your life on, this year, than you have been recently. (ex. doom-scrolling news sites; eating peanut butter out of the jar)<br>
>>[!note]
>>
</p><br>

>[!quote]
>How we direct our moment-to-moment energies is how we spend our days, and how we spend our days is how we spend our lives.<br>
>>[!note]
>>
</p>