URL: https://www.theatlantic.com/magazine/archive/2022/12/haruki-murakami-book-novelist-as-a-vocation/671845/
Author: [[Haruki Murakami]]
Date: [[10-24-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>I think I almost unconsciously pull information and various fragments from the cabinets in my brain and then weave them together.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I have my own name for this process: the Automatic Dwarfs.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I’ve nearly always driven stick-shift cars, and the first time I drove an automatic, I had the feeling that dwarfs must be living inside the gearbox, each in charge of operating a separate gear. I also felt faintly anxious that someday those dwarfs, deciding they’d had enough of slaving away for someone else, would go on strike, and my car would suddenly stop working in the middle of the highway. I know you’ll laugh to hear me say this about the process of creating characters, but it’s as if those Automatic Dwarfs living in my unconscious are, despite a bit of grumbling, somehow managing to work hard.<br>
>>[!note]
>>
</p><br>

>[!quote]
>in the beginning stage of the process, I leave everything up to the Automatic Dwarfs.<br>
>>[!note]
>>
</p><br>

>[!quote]
>if the only people you put in your novels are the kind you like, are interested in, or can easily understand, then your novels will ultimately lack a certain expansiveness. You want all sorts of different people, doing all sorts of different actions, and it’s through that clash of differences that things get moving, propelling the story forward. So you shouldn’t just avert your eyes when you decide you can’t stomach somebody; instead, ask yourself, “What is it I don’t like about them?” and “Why don’t I like that?”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Every time I write a new novel, I tell myself, Okay, here is what I’m going to try to accomplish, and I set concrete goals for myself—for the most part visible, technical types of goals.<br>
>>[!note]
>>
</p><br>

>[!quote]
>As I clear a new hurdle and accomplish something different, I get a real sense that I’ve grown, even if only a little, as a writer. It’s like climbing, step-by-step, up a ladder. The wonderful thing about being a novelist is that even in your 50s and 60s, that kind of growth and innovation is possible. There’s no age limit. The same wouldn’t hold true for an athlete.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The novelist has to put characters in his novel who feel real and are compelling and speak and act in ways that are a bit unpredictable.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Beyond being real, compelling, and somewhat unpredictable, I think what’s even more important is how far a novel’s characters advance the story.<br>
>>[!note]
>>
</p>