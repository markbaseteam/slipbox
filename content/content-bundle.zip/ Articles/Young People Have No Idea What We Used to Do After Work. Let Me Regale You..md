URL: https://slate.com/human-interest/2023/06/life-before-cell-phones-internet-after-work.html
Author: [[Dan Kois]]
Date: [[06-17-2023]]
Tags: [[Sociology MOC]] [[Worklife MOC]] 

>[!tip]
>Good lessons from the pre-smartphone era on how to set expectations re: work/life balance.


## Highlights
<br>

>[!quote]
>Especially since the pandemic and the growth of remote work, job responsibilities seem to be ever-expanding to fill all available time.<br>
>>[!note]
>>With flexibility comes a lack of hierarchical oversight and an increase in hierarchical overreach
</p>