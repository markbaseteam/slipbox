URL: https://samkriss.substack.com/p/the-internet-is-already-over
Author: [[Sam Kriss]]
Date: [[09-18-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>There was an ancient thought: that Zeus feeds on the world. ‘The universe is cyclically consumed by the fire that engendered it.’<br>
>>[!note]
>>
</p><br>

>[!quote]
>Our God is a devourer, who makes things only for the swallowing. As it happens, this was the first thought, the first ever written down in a book of philosophy, the first to survive: that nothing survives, and the blankness that birthed you will be the same hole you crawl into again.<br>
>>[!note]
>>
</p>