URL: https://www.chicagotribune.com/entertainment/books/ct-ent-george-saunders-liberation-day-book-20221024-ovca77fswvdelnvmpz4pfdsiaq-story.html
Author: [[Christopher Borrelli Chicago]]
Date: [[10-24-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>from a Buddhist standpoint, I think I am a guy who is consistent but what is making me think that is a constant stream of thoughts, not from some fixed person but from a bunch of people at any given moment. A lot of the trouble we get in is about how strongly we affix to our idea of self. If I take those thoughts away, does a self disappear?<br>
>>[!note]
>>
</p><br>

>[!quote]
>I’m 63, I look back and think this machine is functioning very similar to the way it was when I was four. That’s beautiful, but also strange that there is a predictability in this self. You see thoughts changing but spend a lot of time remembering, recontextualizing. I am more aware of how impermanent everything is now. There is no solid consciousness here.<br>
>>[!note]
>>
</p>