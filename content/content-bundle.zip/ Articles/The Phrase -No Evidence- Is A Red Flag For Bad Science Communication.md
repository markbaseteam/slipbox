URL: https://getmatter.com/email/1981248/?token=1981248%3ARsxMBRVd_pxY-hngHv8T9lreIeU
Author: [[Scott Alexander]]
Date: [[12-16-2021]]
Tags: 


## Highlights
<br>

>[!quote]
>If it’s worth writing a story about why there’s no evidence for something, probably it’s because some people believe there is evidence. What evidence do they believe in? Why is it wrong? How do you know?<br>
>>[!note]
>>
</p>