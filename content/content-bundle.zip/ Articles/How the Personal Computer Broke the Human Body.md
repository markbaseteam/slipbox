URL: https://www.vice.com/en/article/y3dda7/how-the-personal-computer-broke-the-human-body
Author: [[Joseph Cox]]
Date: [[05-12-2021]]
Tags: [[Health MOC]] [[Technology MOC]]


## Highlights
<br>

>[!quote]
>There was really no precedent in our history of media interaction for what the combination of sitting and looking at a computer monitor did to the human body.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Our bodies, quite literally, were never meant to work this way.<br>
>>[!note]
>>
</p>