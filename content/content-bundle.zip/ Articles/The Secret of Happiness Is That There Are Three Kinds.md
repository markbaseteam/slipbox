URL: https://etiennefd.substack.com/p/the-secret-of-happiness-is-that-there
Author: [[Étienne Fortier-Dubois]]
Date: [[05-04-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>psychological richness.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Hedonism is goodness that focusses on comfort, security, pleasure, and having money, time and fulfilling relationships.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Eudaimonia is goodness that focusses on having a purpose, upholding moral principles, and contributing to society.<br>
>>[!note]
>>
</p><br>

>[!quote]
>While this dichotomy is conceptually useful, it doesn’t imply stark opposition.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Psychological richness is goodness that focusses on having interesting experiences, novelty, changes in perspective, and adventure.<br>
>>[!note]
>>
</p><br>

>[!quote]
>my whole personality seems geared towards psychological richness. I’m endlessly curious, and I can nerd out about almost any topic; I even have trouble defining what I’m interested in (for example, in order to describe this newsletter) because there are too many things that could fit.<br>
>>[!note]
>>
</p><br>

>[!quote]
>This quest for diversity has even been an obstacle to, for example, adopting vegetarianism. I know that you can eat well (happily) without meat; I care somewhat about the (meaningful) ethical implications; but eating a diverse diet, for me, trumps both of these concerns. A diet without meat is strictly less diverse than a diet with it, so to me it is inferior.<br>
>>[!note]
>>
</p>