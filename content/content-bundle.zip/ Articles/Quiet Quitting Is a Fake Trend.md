URL: https://www.theatlantic.com/newsletters/archive/2022/09/quiet-quitting-trend-employee-disengagement/671436/
Author: [[Derek Thompson]]
Date: [[09-16-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>When a phrase takes off, it's often because the new words fill a vacuum.<br>
>>[!note]
>>
</p>