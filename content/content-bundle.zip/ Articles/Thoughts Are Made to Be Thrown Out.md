URL: https://getmatter.com/email/19621661/?token=19621661%3Adlgv_tpg7OsG4SemHh0Tr6sOhzc
Author: [[David Cain]]
Date: [[02-15-2023]]
Tags: [[Psychology MOC]] 


## Highlights
<br>

>[!quote]
>Recognizing thought for what it is — a mild hallucination that offers a physically safer form of trial and error — can spare us a lot of that kind of suffering.<br>
>>[!note]
>>
</p><br>

>[!quote]
>We need to make sure we dispose of thoughts after they’ve made their appeal, because they’ll stick around as long as you let them.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Throwing out thoughts is something to practice, using a technique like Corner Glimpsing or just by uttering an inner “No thanks” and doing something with the body instead. You just drop it and move, putting your attention into anything physical and real.<br>
>>[!note]
>>
</p><br>

>[!quote]
>This “drop-and-move-on” move feels dangerous at first. This is because the mind knows you’re abandoning mental trial-and-error for the physical kind again, and the mind’s entire purpose is to keep the body from messing itself up in the real world. The mind forgets, though, that ultimately the body is the part of you that has to get on with things and live in that real world, and nothing good can happen until it starts doing that again.<br>
>>[!note]
>>
</p>