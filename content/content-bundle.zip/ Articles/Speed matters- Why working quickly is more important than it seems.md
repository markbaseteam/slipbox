URL: http://jsomers.net/blog/speed-matters
Author: [[James Somers]]
Date: [[07-26-2015]]
Tags: [[Learning MOC]] [[Psychology MOC]] [[Worklife MOC]] [[Writing MOC]] 

>[!tip]
>Good piece about time, speed, productivity


## Highlights
<br>

>[!quote]
>This is true of any to-do list that gets worked off too slowly. A malaise creeps into it. You keep adding items that you never cross off. If that happens enough, you might one day stop putting stuff onto the list.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The general rule seems to be: systems which eat items quickly are fed more items. Slow systems starve.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Unresponsive systems are sad. They’re like buildings grown over with moss. They’re a kind of memento mori.<br>
>>[!note]
>>Should [[memento mori]] be a concept?
</p><br>

>[!quote]
>Part of the activation energy required to start any task comes from the picture you get in your head when you imagine doing it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>It may not be that going for a run is actually costly; but if it feels costly, if the picture in your head looks like a slog, then you will need a bigger expenditure of will to lace up.<br>
>>[!note]
>>In the pandemic, the cost changed because the supply and demand changed. Time costs went down because there was less competition in the time marketplace. A lot of us probably miss that openness #seed
</p>