URL: https://www.are.na/blog/notes-on-taste
Author: [[Brie Wolfson]]
Date: [[05-05-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>10. While taste is often focused on a single thing, it is often formed through the integration of diverse, and wide-ranging inputs.<br>
>>[!note]
>>
</p><br>

>[!quote]
>here are my notes on “taste.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>taste is a mode. It’s a manner of interpretation, expression, or action.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Appreciation is a form of taste. Creation is another. They are often intertwined, but don’t have to be.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Someone could have impeccable taste in art, without producing any themselves. Those who create tasteful things are almost always deep appreciators, though.<br>
>>[!note]
>>
</p><br>

>[!quote]
>There are degrees of taste, but we typically talk about it in binaries. One can have taste or not. Great taste means almost the same thing as taste.<br>
>>[!note]
>>
</p><br>

>[!quote]
>taste isn’t often outgrown.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Though taste may appear effortless, you can’t have taste by mistake. It requires intention, focus, and care.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Taste comes in lanes.<br>
>>[!note]
>>
</p><br>

>[!quote]
>there is taste in acts, taste in morality. Intelligence, as well, is really a kind of taste: taste in ideas.<br>
>>[!note]
>>
</p><br>

>[!quote]
>taste tends to develop very unevenly. It's rare that the same person has good visual taste and good taste in people and taste in ideas.” The sought-after interior designer may not mind gas station coffee. The prolific composer may not give a damn about how they dress.<br>
>>[!note]
>>
</p><br>

>[!quote]
>To have taste is to be persnickety and one doesn’t want to be persnickety or annoyed about too many things.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Irony and satire are frenemies of taste.<br>
>>[!note]
>>
</p><br>

>[!quote]
>“‘Good taste' is simply to have a well formed opinion, in accordance with the realities of the Good and the True.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Taste is not the same as correctness, though.<br>
>>[!note]
>>
</p><br>

>[!quote]
>taste gets you to the thing that’s more than just correct. Taste hits different. It intrigues. It compels. It moves. It enchants. It fascinates. It seduces.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Taste requires originality. It invokes an aspirational authenticity. Writer George Saunders calls this “achieving the iconic space,” and it’s what he’s after when he meets his creative writing students. “They arrive already wonderful. What we try to do over the next three years is help them achieve what I call their “iconic space” — the place from which they will write the stories only they could write, using what makes them uniquely themselves…At this level, good writing is assumed; the goal is to help them acquire the technical means to become defiantly and joyfully themselves.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Another framing for this is “turpentine.” It comes from Picasso remarking that “when art critics get together they talk about Form and Structure and Meaning. When artists get together they talk about where you can buy cheap turpentine.” Taste rests on turpentine.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Be patient, the process of metabolizing the world is a slow one. Wield your P/N meter well, take your time learning what you find compelling, and why.<br>
>>[!note]
>>
</p>