URL: https://www.theatlantic.com/ideas/archive/2023/07/harvard-admissions-affirmative-action-elite-colleges/674837/
Author: [[Jerusalem Demsas]]
Date: [[07-27-2023]]
Tags: [[Education MOC]] [[Sociology MOC]] 

>[!tip]
>Great piece on affirmative action and some of the most pressing issues with education systems.


## Highlights
<br>

>[!quote]
>No one deserves a seat at Harvard, but only some people are supposed to feel bad about the one they get.<br>
>>[!note]
>>
</p><br>

>[!quote]
>no one “deserves” to gain admission anywhere. No university can construct a perfectly meritocratic system. How should an admissions program distinguish among tens of thousands of standout students fairly?<br>
>>[!note]
>>
</p><br>

>[!quote]
>Any method of distinguishing among such applicants is inherently subjective, and any of the traits, acquired skills, or backgrounds that help push students over the edge could be considered “unearned advantage.” But none of those carries the stigma that race-based affirmative action does. The whispers of affirmative action never leave the people of color who enter into elite spaces; they become the targets of resentment for the unfulfilled ambitions of their fellow students and, later on, their colleagues.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Affirmative action is an albatross, whereas other forms of unearned privilege are, if anything, a sign of belonging.<br>
>>[!note]
>>
</p><br>

>[!quote]
>In a system that requires subjective discrimination, no one is objectively best qualified.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Could the Supreme Court’s decision finally convince the general public that the Black students who are admitted belong? I doubt it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The sooner we accept that no one deserves to be an elite, the better.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Should a handful of private institutions benefiting from billions of dollars in taxpayer subsidies and tax breaks and other public monies get to select our political, economic, and cultural leaders behind closed doors? Sure, it’s better if they do so without employing harmful racial stereotypes. Better still if they stop putting their thumbs on the scale for the top 0.1 percent. But fighting over the appropriate racial composition of the future white-collar lawyers and corporate consultants of America only legitimizes the enterprise to begin with.<br>
>>[!note]
>>Self-perpetuating influence ecosystem of universities and higher ed. Abolish the system.
</p>