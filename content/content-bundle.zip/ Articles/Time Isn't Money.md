URL: https://www.youngmoney.co/p/time-isnt-money-b288
Author: [[Jack Raines]]
Date: [[03-14-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Some luxuries won't make your life any better, but losing them after having experienced them will certainly make your life worse. - Nassim Taleb<br>
>>[!note]
>>
</p><br>

>[!quote]
>Money is infinite, time is finite. These are the two rules of the game. To maximize your satisfaction from the game, you need to know how much money is enough, you need to make money without sacrificing time, and you need to be able to afford the experiences that you want in life.<br>
>>[!note]
>>
</p>