URL: https://simonsarris.substack.com/p/where-to-live
Author: [[Simon Sarris]]
Date: [[08-25-2020]]
Tags: 


## Highlights
<br>

>[!quote]
>Cities seem to exert themselves on people, like a kind of peer-pressure, and they do it so thoroughly I’m not sure the people inside the cities fully know it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The really important thing isn’t where you live exactly, but being embodied in your living regardless of where you are. Perhaps that’s the interesting topic here, but it will have to wait for now.<br>
>>[!note]
>>
</p>