URL: https://jasminewang.substack.com/p/attending-to-the-other
Author: [[Jasmine Wang]]
Date: [[12-06-2021]]
Tags: [[Communication MOC]] [[Philosophy MOC]] [[Sociology MOC]] 

>[!tip]
>Possible concepts: [[witness]] c/o [[David Whyte]] – the ultimate touchstone of friendship (rather than helping each other get better, the idea is to be seen/recognized/heard)


## Highlights
<br>

>[!quote]
>The poet David Whyte said that "the ultimate touchstone of friendship is not improvement, neither of the other nor of the self. The ultimate touchstone is witness, the privilege of having been seen by someone, and the equal privilege of being granted the sight of the essence of another, to have walked with them, and to have believed in them, and sometimes, just to have accompanied them, for however brief a span, on a journey impossible to accomplish alone".<br>
>>[!note]
>>
</p><br>

>[!quote]
>One way to practice attention is to notice the non-logical aspects of communication.<br>
>>[!note]
>>
</p>