URL: https://every.to/almanack/oatly-the-new-coke-821556
Author: [[Nat Eliason]]
Date: [[08-06-2020]]
Tags: 


## Highlights
<br>

>[!quote]
>The playbook, outlined in detail in Merchants of Doubt, is very simple:<br>
>>[!note]
>>
</p><br>

>[!quote]
>Obscure the Truth: Make vague health claims that aren’t falsifiable.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Create Confusion: Fund massive amounts of research papers showing the harmful ingredients are healthy, or at least not provably harmful.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Strawman the Disagreements: When people criticize the ingredients or health claims, strawman their arguments by focusing on the most easily dismissed criticisms, or by pointing the finger elsewhere.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Oatly’s main ingredient is their oat base, which they make through a process of breaking down raw oats into their loose fibers to mix them with water and create a watery oat-based liquid that “contains macronutrients from the oats, in other words, protein, fat, and carbohydrates.” (source).<br>
>>[!note]
>>
</p><br>

>[!quote]
>The problem with this process is that it creates quite a bit of a sugar called maltose, which is why Oatly packaging shows 7g added sugar per serving. Of all the different kinds of sugars you can eat, maltose has the highest glycemic index, with a rating of 105 out of 100. For comparison, table sugar has a rating of 65, and the high-fructose corn syrup you get in a Coca-Cola has a GI around 65-75. There’s less of it, but the sugar in Oatly has a higher gram-for-gram impact on your blood sugar than the HFCS in Coca-Cola.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Oatly’s second ingredient after the oat base is “low erucic acid rapeseed oil” which is another name for canola oil.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The evidence for the harms of canola oil is still in its early days, but continues to grow. Research has linked it to: Memory impairment [1], Alzheimer’s risk [1], Cardiovascular disease [2], [5], [6], [8], Diabetes [2], Increased all-cause mortality [2], [6], [7], Metabolic syndrome [3], Decreased brain function [4], and Oxidative stress [5], [7].<br>
>>[!note]
>>
</p>