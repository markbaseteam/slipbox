URL: https://ez.substack.com/p/the-death-of-productivity
Author: [[Ed Z]]
Date: [[10-21-2022]]
Tags: 

>[!tip]
>Looking busy and being busy are fundamentally different things... and only managers care about you looking busy, because THEIR bosses are removed from touchpoints and the work itself, and thus don't trust that you do anything


## Highlights
<br>

>[!quote]
>Many remote workers have two jobs - their actual job, and the moronic sideshow of placating a manager that wants to think that you’re “busy.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>I am sick and tired of this conversation because there are really only two answers: you are either a business that evaluates what people do for work, or you are a vibes-based half-business managed by cretins that have no concept of reality. This is because the business world has become obsessed with the concept of “productivity” while somehow entirely ignoring the meaning of the concept. Productivity refers to the production of an output - when someone is “productive,” it’s meant to mean that they are producing, as production is the direct result of productivity. Production produces outputs, which is why you know someone is productive - because they are producing.<br>
>>[!note]
>>
</p><br>

>[!quote]
>I’d argue that as businesses have grown the gulf between the producer and the recipient of the majority of the capital in the business (bosses and managers), businesses have become distanced from the concept of productivity entirely. As I wrote last year for The Altantic, we societally “tend to consider management a title rather than a skill, something to promote people to” rather than something people do, and the net result of this degenerative idea is that companies no longer actually care about production.<br>
>>[!note]
>>
</p><br>

>[!quote]
>People are hired based on confirmed biases, aesthetics, charm, “culture fit” and anything other than “will they do this job well and make the business better without making everyone miserable,” because, realistically, so many people hiring and managing other people don’t know what the fuck it is they do.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Productivity paranoia is the emperor feeling the breeze on his genitals despite his perfectly-appointed outfit. Anybody that has uttered or been concerned about this term acknowledges that they are not really interested in productivity, but in the warm feeling that they’re “getting the most” out of the people working for them. “Getting the most” out of someone without measuring their actual productivity - their production - is abjectly stupid, and yet appears to be how most business publications and managers evaluate their workers.<br>
>>[!note]
>>
</p>