URL: https://onartandaesthetics.com/2016/10/01/gardens-an-essay-on-the-human-condition/
Author: [[Tulika Bahadur]]
Date: [[10-01-2016]]
Tags: [[Aesthetics MOC]] [[History MOC]] [[Life Design MOC]] [[Philosophy MOC]] 


## Highlights
<br>

>[!quote]
>Human beings, Harrison says in the beginning, are not ultimately made to look too intently at the head of Medusa [monster from Greek mythology], that is, at rage, death, and endless suffering. He writes: This is not a shortcoming on our part; on the contrary, our reluctance to let history’s realities petrify us underlies much of what makes human life bearable: our religious impulses, our poetic and utopian imagination, our moral ideals, our metaphysical projections, our storytelling, our aesthetic transfigurations of the real, our passion for games, our delight in nature.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Gardens are a mechanism by which we make life bearable.<br>
>>[!note]
>>
</p><br>

>[!quote]
>“For millennia and throughout world cultures,” asserts Robert Pogue Harrison, “our predecessors conceived of human happiness in its perfected state as a garden existence.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>But the purpose always remains the same. If not a kind of heaven, they are a kind of haven. Also, they are not private concerns but a common enterprise. This is something that the French philosopher Voltaire understood. Il faut cultiver notre jardin – we must cultivate our garden – he said at the end of his satire Candide(1759).<br>
>>[!note]
>>
</p><br>

>[!quote]
>Notre jardin is that plot of soil on the earth, within the self, or amid the social collective, where “the cultural, ethical, and civic virtues that save reality from its own worst impulses are cultivated. Those virtues are always ours.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>In a garden where everything pre-exists spontaneously and perfectly, we would surely succumb to ennui. This was, in a way, the problem with Eden. The Fall may have been a curse for any number of reasons but it was a blessing in so far it made Eve and Adam engaged cultivators of the world. It saved them from mindless and feckless bliss. It endowed them with a depth and a density. It enabled them to earn heart. With the possibility of mortality, came the prospect of “natality” – the initiation of new beginnings through human action [a concept used by the influential German-Jewish political thinker Hannah Arendt (1906-1975)].<br>
>>[!note]
>>Super interesting framing of the Eden story in the Christian Bible. [[Natality]] should be explored as a concept 

From a God POV, it was a curse. From a human POV, it imbued our lives with purpose, meaning, texture. Should [[texture]] be a concept? #Seed
</p><br>

>[!quote]
>Eve’s transgression was the first true instance of human action, properly understood. It was in itself already an act of motherhood, for through it she gave birth to the mortal human self, which realizes its potential in the unfolding of time, be it through work, procreation, art, or the contemplation of things divine. God should have foreseen that by endowing Eve with a potential for natality, he made it painful for her to endure the sterile mirror which the garden reflected back on her.<br>
>>[!note]
>>This is so fascinating. Mother Nature is Eve?
</p><br>

>[!quote]
>Capitalistic and technological forces have engendered a frantic cult of consumerism, have laid before us an inexhaustible inventory for human consumption. The dominant impulse of the system is to perpetuate its own dynamism rather than to fulfill an end. We want to re-Edenise the world but, in our restlessness and heedlessness, are doing so by mounting assault after assault on Creation. “Our action does not so much bear fruit as devour fruit,” notes Harrison. “Thus we find ourselves in the paradoxical situation of seeking to re-create Eden by ravaging the garden itself—the garden of the biosphere on the one hand and the garden of human culture on the other.”<br>
>>[!note]
>>The paradox of chasing paradise without understanding the context in which we first encountered it
</p>