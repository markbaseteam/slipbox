URL: https://hedgehogreview.com/issues/hope-itself/articles/on-hope-and-holy-fools
Author: [[]]
Date: [[Invalid date]]
Tags: 


## Highlights
<br>

>[!quote]
>Tragedy, and its narrative consummation, are sexy, in a way comedy cannot be.<br>
>>[!note]
>>
</p><br>

>[!quote]
>And what if life were a comedy? What would it mean to live—mawkish though the thought might be—in expectation of an ending replete with joyful reversal and romantic reconciliation,<br>
>>[!note]
>>
</p><br>

>[!quote]
>What would it mean to understand ourselves not as tragic heroes, solitary in our revelations, but as ordinary people, whose lives are lived entwined with one another, maybe even in prose?<br>
>>[!note]
>>
</p><br>

>[!quote]
>What if the truth of our lives lay not in our self-separation from the sheeple but in our embrace of the fact that the life we live with one another is the truest expression of who we really are: that there is as much weight to our kid brother kissing us, gently, in the middle of our existential crisis, as there is in the substance of the crisis itself?<br>
>>[!note]
>>
</p><br>

>[!quote]
>Such a reading of our lives demands humility. It asks that we envision ourselves not as special or distinct but as ordinary human beings, those shepherds and butlers and housemaids, whose ordinary lives are as worthy of attention as those of tragedy’s kings and warriors. It insists, as a moral and philosophical duty, that we take ourselves not more seriously but less, that we learn to laugh at ourselves. It demands that, instead of aestheticizing our foibles—raising our sins to the substance of high art—we see ourselves as, well, a little bit silly, perhaps well intentioned, but constantly getting in our own way: Gilligans failing in every single episode to get off the island.<br>
>>[!note]
>>
</p><br>

>[!quote]
>To accept grace—the undeserved happy ending—demands that we see our lives as a comedy (as Dante indeed understood). In order to accept our lives as a comedy, we must accept that none of us are the heroes we imagine ourselves to be.<br>
>>[!note]
>>
</p><br>

>[!quote]
>This is the truth understood by Dostoevsky’s Alyosha and by the wider Russian tradition of the “holy fool”: the innocent whose faith in God causes him to appear stupid, if not mad, in the eyes of the world.<br>
>>[!note]
>>
</p><br>

>[!quote]
>To hope is a kind of foolishness. It is, too, a kind of refusal of the aesthetic,<br>
>>[!note]
>>
</p><br>

>[!quote]
>It is a quieter kind of bravery: the conviction that, one day, we might not have to. It may not be narrative. But it remains, instead, poetry.<br>
>>[!note]
>>
</p>