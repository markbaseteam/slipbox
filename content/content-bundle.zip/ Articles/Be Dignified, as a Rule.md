URL: https://getmatter.com/email/21796360/?token=21796360%3AxlXbV0JvfXIiG95F4rUN4rAzqkg
Author: [[David Cain]]
Date: [[03-27-2023]]
Tags: [[Philosophy MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>Dignity doesn’t follow effectiveness as much as effectiveness follows dignity.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Perhaps we should have dignity foremost in mind whenever we do anything, because it’s an intuitive sense we all have, and it points the way to a thing done well.<br>
>>[!note]
>>
</p><br>

>[!quote]
>What feels dignified depends on the person, but we can always sense our own dignity, or lack thereof, in how we do a thing, even when nobody else is there to see it.<br>
>>[!note]
>>
</p><br>

>[!quote]
>A little more intentionality, a lot more dignity.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Technology tends to pull us away from this way of being, eroding dignity in the quest for speed, variety, or convenience.<br>
>>[!note]
>>[[Dignity]] is the anti-speed, the slow growth, the fermentation. There is dignity in [[fermentation]]
</p><br>

>[!quote]
>I find it more dignified, for example, to listen to music by playing a single album, rather than an AI-generated playlist.<br>
>>[!note]
>>Where do curation and dignity meet? Is there such a thing is dignified curation?
</p><br>

>[!quote]
>The more our tools automate once-manual actions, and the more we access them all through the same lifeless touchscreen, the less intentionality and resolve there is behind whatever we’re doing.<br>
>>[!note]
>>Ahh so dignity is doing…

Dignity is human powered processes 

Dignity through human ignition
</p><br>

>[!quote]
>The steaming of vegetables is a little easier of course, but the greater gain was in becoming the person who fixed the thing that needs fixing, and no longer the person oppressed by his faulty steamer basket.<br>
>>[!note]
>>Dignity is a process of greater gain, recognizing the result of an action is not just the direct outcome, but a host of indirect benefits
</p>