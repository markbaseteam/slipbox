URL: https://www.theatlantic.com/ideas/archive/2022/05/population-growth-housing-climate-change/629952/
Author: [[Jerusalem Demsas]]
Date: [[05-24-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>Although major organizations have abandoned population management as an explicit policy goal, the underlying fear that too many people are running up on the limits of too few resources and Well shouldn’t someone do something about that? has never fully been rooted out of American political thought. It is alive and well among NIMBYs.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Invariably, the problem is always other people.<br>
>>[!note]
>>
</p><br>

>[!quote]
>antihuman thinking has permeated discourses all over the nation—and the world.<br>
>>[!note]
>>
</p><br>

>[!quote]
>population growth is not the problem that so many people seem to think it is, not least because of the global decline in fertility; arguably, declining population growth is the real population-related concern of the century. And even if it were a concern, the policies that NIMBYs support not only fail to create a climate-conscious built environment but actually make fighting climate change more difficult.<br>
>>[!note]
>>
</p><br>

>[!quote]
>What should be obvious, but apparently is not, is that opposing immigration actually reduces the U.S.’s ability to cultivate and take advantage of brilliant people who could develop the technological advances to save the planet. (Thirty-seven percent of American Nobel Prize winners in chemistry, medicine, and physics from 2000 to 2020 have been immigrants.)<br>
>>[!note]
>>
</p><br>

>[!quote]
>economist Hisakazu Kato argued in 2016 that “a large population will generate many ideas that could bring about rapid technological progress.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>Overpopulation concern-mongers not only underestimate the ability of people to help solve the problems of climate change; they also fail to accept that neither resources nor human needs are fixed. The idea that resources will “run out” implies that human ingenuity will remain stagnant. But it doesn’t.<br>
>>[!note]
>>
</p><br>

>[!quote]
>The evidence is clear, and has been for some time, that density is good for the environment. As UC Berkeley researchers argued in a 2014 paper, “population-dense cities contribute less greenhouse-gas emissions per person than other areas of the country,” and “the average carbon footprint of households living in the center of large, population-dense urban cities is about 50 percent below average, while households in distant suburbs are up to twice the average.”<br>
>>[!note]
>>
</p><br>

>[!quote]
>But the people worried about other people don’t have a pro-density history; quite the opposite. As the urban planner Greg Morrow detailed in his 2013 dissertation, overpopulation activists fought for the very legal frameworks that would keep cities low-density and worsen suburban sprawl.<br>
>>[!note]
>>
</p><br>

>[!quote]
>NIMBYs and overpopulation skeptics share a sense that the world is too full, that their communities are for the people who already live there, and that new people—immigrants from abroad or the next state over—are simply burdens. And in doing so, they create the world they imagine: unacceptable rates of homelessness, a country lagging far behind its peers in building mass transit, and declining trust.<br>
>>[!note]
>>
</p><br>

>[!quote]
>If overpopulation is the hill you want to die on, then you’ve got to defend the implications.<br>
>>[!note]
>>
</p>