URL: https://kyla.substack.com/p/everyone-is-frolicking-but-me
Author: [[Kyla Scanlon]]
Date: [[06-08-2023]]
Tags: 


## Highlights
<br>

>[!quote]
>Because most Americans say they’re personally fine, they might resist too much experimentation. This creates a confusing voting bloc, which is constantly angry about the state of things, but also fundamentally conservative about any change that overturns their “rather happy” life and “at least okay” finances.<br>
>>[!note]
>>
</p>