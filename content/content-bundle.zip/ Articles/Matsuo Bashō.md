URL: https://twitter.com/i/web/status/1583398333426520064
Author: [[The School of Life]]
Date: [[10-21-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>two of the supreme virtues of zen Buddhism — ‘wabi’ and ‘sabi’. Wabi = love of solitude Sabi = love of whatever is natural and imperfect Wabi-sabi, according to Zen teaching, can best be experienced through periods of isolation in nature.<br>
>>[!note]
>>
</p><br>

>[!quote]
>For Bashō, poetry wasn’t just an artform. It was a way of life. Poetry was the key to a more present, peaceful and fulfilled existence. What was the secret of Bashō’s genius? And what is he trying to teach us about how we should live? Bashō’s key aesthetic principle was ‘karumi’: lightness.<br>
>>[!note]
>>
</p><br>

>[!quote]
>If we wish to follow Bashō’s example, we should aspire to greater simplicity — in our material circumstances, and in how we communicate with others.<br>
>>[!note]
>>
</p><br>

>[!quote]
>he believed that both the writing and reading of haiku could lead to ‘muga’ — literally, ‘no-self’, or a freedom from self. This is a central tenet of Zen Buddhism. Our self-obsession is the source of all our suffering. Only by escaping the ‘I’ can we find peace.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Bashō’s verses enact a kind of ‘muga’: directing our attention away from the ‘I’ and towards the natural world. By paying closer attention to the sights and sounds of nature, we can escape our petty concerns and preoccupations and feel more connected to the world we inhabit. Bashō’s poems were immediately popular with the Japanese audience of his day. But they speak with an even greater urgency to those of us living in the modern west — materially-focused, status-obsessed, ego-centred and imprisoned in unchanging routines.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Today, Bashō is celebrated as Japan’s most popular and masterful poet, the unchallenged master of the haiku. He should also be seen as one of our wisest philosophers.<br>
>>[!note]
>>
</p>