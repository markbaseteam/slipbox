URL: https://simonsarris.substack.com/p/in-praise-of-the-gods
Author: [[Simon Sarris]]
Date: [[07-19-2020]]
Tags: 


## Highlights
<br>

>[!quote]
>The mythos we create is the opposite of nihilism, it is the definite optimism of the power of the world waiting be lured back by us.<br>
>>[!note]
>>
</p>