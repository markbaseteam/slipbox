URL: https://simonsarris.substack.com/p/that-which-is-unique-breaks
Author: [[Simon Sarris]]
Date: [[12-15-2020]]
Tags: 


## Highlights
<br>

>[!quote]
>When the unique is created, it also creates the creator.<br>
>>[!note]
>>
</p>