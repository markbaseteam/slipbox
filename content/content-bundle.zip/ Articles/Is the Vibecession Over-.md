URL: https://kyla.substack.com/p/is-the-vibecession-over
Author: [[Kyla Scanlon]]
Date: [[07-27-2023]]
Tags: [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>The aim of art, the aim of a life can only be to increase the sum of freedom and responsibility to be found in every man and in the world. It cannot, under any circumstances, be to reduce or suppress that freedom, even temporarily. No great work has ever been based on hatred and contempt. On the contrary, there is not a single true work of art that has not in the end added to the inner freedom of each person who has known and loved it.<br>
>>[!note]
>>[[Albert Camus]] said this, and it's entirely prescient about our current predicament
</p>