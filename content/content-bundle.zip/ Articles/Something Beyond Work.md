URL: https://getmatter.com/email/29298281/?token=29298281%3AaB4YHUt3CU7JnWz6xiGNKYGp4yE
Author: [[Stowe Boyd]]
Date: [[08-13-2023]]
Tags: [[Sociology MOC]] [[Urbanism MOC]] [[Worklife MOC]] 


## Highlights
<br>

>[!quote]
>The median American rides transportation zero times each year. | Brian Taylor cited by David Zipper.<br>
>>[!note]
>>This is CRAZY. [[Urbanism MOC]]
</p><br>

>[!quote]
>The case for proximity. Arena: ‘One of the great reasons to come to the workplace is to be in physical proximity to folks that you can learn from. This is particularly true for younger people who want to learn their craft. Think back on your own career to a great manager or a great coach you had. Those learnings are key.<br>
>>[!note]
>>I like this, it’s a really under-covered benefit of moving away from ONLY remote work.  

It also makes the case for brainstorming as a key feature of in-person work, and why we need to normalize brainstorms. They get a bad wrap, but we need to redefine what a successful brainstorm yields
</p>