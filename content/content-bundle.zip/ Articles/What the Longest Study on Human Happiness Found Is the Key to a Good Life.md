URL: https://www.theatlantic.com/ideas/archive/2023/01/harvard-happiness-study-relationships/672753/
Author: [[Marc Schulz]]
Date: [[01-19-2023]]
Tags: [[Philosophy MOC]] [[Sociology MOC]] 


## Highlights
<br>

>[!quote]
>Looking in the mirror and thinking honestly about where your life stands is a first step in trying to live a good life.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Noticing where you are can help put into relief where you would like to be.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Loneliness has a physical effect on the body. It can render people more sensitive to pain, suppress their immune system, diminish brain function, and disrupt sleep, which in turn can make an already lonely person even more tired and irritable.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Research has found that, for older adults, loneliness is far more dangerous than obesity.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Alleviating this epidemic of loneliness is difficult because what makes one person feel lonely might have no effect on someone else.<br>
>>[!note]
>>
</p>