URL: https://www.bbc.com/future/article/20220929-how-outdoor-play-boosts-kids-immune-systems
Author: [[Alessia Franco]]
Date: [[10-10-2022]]
Tags: 


## Highlights
<br>

>[!quote]
>According to recent research, the dirt outside is teaming with friendly microorganisms that can train the immune system and build resilience to a range of illnesses, including allergies, asthma and even depression and anxiety.<br>
>>[!note]
>>
</p><br>

>[!quote]
>These findings show that outdoor exercise is not only beneficial because of the chance to roam free – but that certain natural materials, such as soil and mud, also contain surprisingly powerful microorganisms whose positive impact on children's health we are only beginning to fully understand.<br>
>>[!note]
>>
</p><br>

>[!quote]
>it is the non-infectious organisms that are now thought to be key – rather than the ones that actually make our children sick. These "old friends" have been around for much of our evolutionary history. They are mostly harmless, and train the immune system to moderate its activity, rather than overreacting to any potential invader.<br>
>>[!note]
>>
</p><br>

>[!quote]
>our bodies meet these old friends whenever we spend time in nature.<br>
>>[!note]
>>
</p><br>

>[!quote]
>Various studies support this idea. People who grow up on farms are generally less likely to develop asthma, allergies, or auto-immune disorders like Crohn's disease – thanks, apparently, to their childhood exposure to a more diverse range of organisms in the rural environment that had encouraged more effective regulation of the immune system.<br>
>>[!note]
>>
</p>